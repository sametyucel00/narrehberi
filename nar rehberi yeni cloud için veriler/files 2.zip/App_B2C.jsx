/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  NAR REHBERİ — ANA UYGULAMA (B2C)                              ║
 * ║  App_B2C.jsx  →  src/App.jsx olarak kullan                     ║
 * ║                                                                  ║
 * ║  Akış:                                                           ║
 * ║    ONBOARDING  →  VITRIN (KategoriVitrin)                       ║
 * ║    Header'daki "Yönetim" butonu  →  AuthGateway                 ║
 * ║    DT_ADMIN rolü  →  TheaterAdminPanel_v8                       ║
 * ║    MASTER rolü    →  MasterPanel_final                          ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

import OnboardingScreen from "./OnboardingScreen.jsx";
import KategoriVitrin   from "./KategoriVitrin.jsx";

/*
  Hazır olduğunda yorumu kaldır:
  import AuthGateway       from "./AuthGateway.jsx";
  import TheaterAdminPanel from "./TheaterAdminPanel_v8.jsx";
  import MasterPanel       from "./MasterPanel_final.jsx";
*/

/* ─── TEMA ──────────────────────────────────────────────────────── */
const C = {
  bg:     "#0a0a0f",
  s2:     "#111118",
  gold:   "#D4AF37",
  goldD:  "rgba(212,175,55,0.10)",
  goldB:  "rgba(212,175,55,0.18)",
  text:   "rgba(238,230,210,0.92)",
  muted:  "rgba(168,155,128,0.48)",
  ok:     "#4caf7d",
  danger: "#c0604a",
};

/* ─── ONBOARDING KALICI OTURUM ──────────────────────────────────── */
const OB_KEY = "nar_session_v1";

function loadSession() {
  try {
    const raw = localStorage.getItem(OB_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}
function saveSession(s) {
  try { localStorage.setItem(OB_KEY, JSON.stringify(s)); } catch {}
}
function clearSession() {
  try { localStorage.removeItem(OB_KEY); } catch {}
}

/* ─── NAR HEADER ────────────────────────────────────────────────── */
function NarHeader({ session, onAdmin, onCikis }) {
  return (
    <motion.header
      initial={{ opacity:0, y:-10 }}
      animate={{ opacity:1, y:0 }}
      style={{
        background: C.s2,
        borderBottom:`1px solid ${C.goldB}`,
        padding:"13px 18px",
        display:"flex", justifyContent:"space-between",
        alignItems:"center",
        position:"sticky", top:0, zIndex:200,
      }}>

      {/* Logo */}
      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
        <span style={{ fontFamily:"'Cormorant Garamond','Garamond',serif",
          fontSize:19, color: C.gold, fontWeight:700,
          letterSpacing:"0.06em" }}>
          🍎 Nar
        </span>
        <div style={{ width:1, height:15, background: C.goldB }}/>
        <span style={{ fontSize:8.5, color: C.gold, opacity:0.58,
          letterSpacing:"0.22em", textTransform:"uppercase" }}>
          Rehberi
        </span>
      </div>

      {/* Sağ */}
      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
        {/* Konum göstergesi */}
        {session?.coords && (
          <motion.span animate={{ opacity:[0.5,1,0.5] }}
            transition={{ duration:2.5, repeat:Infinity }}
            style={{ fontSize:9, color: C.ok, letterSpacing:"0.1em" }}>
            ◎ Konum Aktif
          </motion.span>
        )}

        {/* Yönetim / Çıkış */}
        <button
          onClick={onAdmin}
          style={{
            background:"none",
            border:`1px solid ${C.goldB}`,
            borderRadius:3, padding:"6px 13px",
            color: C.gold, cursor:"pointer",
            fontSize:10, letterSpacing:"0.1em",
          }}>
          Yönetim
        </button>
      </div>
    </motion.header>
  );
}

/* ─── VİTRİN SAYFASI ────────────────────────────────────────────── */
function VitrinPage({ session, onAdmin, onCikis }) {

  const karsilama = {
    TR: "Antalya'nın en iyileri sizi bekliyor.",
    EN: "Antalya's finest awaits you.",
    RU: "Лучшее в Анталии ждёт вас.",
    DE: "Das Beste von Antalya wartet auf Sie.",
  };

  return (
    <motion.div key="vitrin"
      initial={{ opacity:0 }} animate={{ opacity:1 }}
      exit={{ opacity:0 }} transition={{ duration:0.35 }}>

      <NarHeader session={session} onAdmin={onAdmin} onCikis={onCikis}/>

      <div style={{ padding:"22px 16px" }}>

        {/* Kişiselleştirilmiş Banner */}
        <motion.div
          initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }}
          style={{
            background: C.goldD,
            border:`1px solid ${C.goldB}`,
            borderRadius:5, padding:"12px 15px",
            display:"flex", justifyContent:"space-between",
            alignItems:"center", marginBottom:24,
          }}>
          <div>
            <p style={{ fontSize:9, letterSpacing:"0.2em",
              color: C.gold, opacity:0.65, marginBottom:3,
              textTransform:"uppercase" }}>
              HOŞ GELDİNİZ
            </p>
            <p style={{ fontSize:12, color: C.text, lineHeight:1.5 }}>
              {karsilama[session?.lang] || karsilama.TR}
            </p>
          </div>
          {!session?.coords && (
            <span style={{ fontSize:9, color: C.muted,
              letterSpacing:"0.08em" }}>
              Konum yok
            </span>
          )}
        </motion.div>

        {/* KATEGORİ VİTRİN */}
        <KategoriVitrin
          coords={session?.coords ?? null}
          lang={session?.lang ?? "TR"}
        />

        {/* Dev sıfırlama */}
        <div style={{ textAlign:"center", marginTop:24 }}>
          <button
            onClick={() => { clearSession(); window.location.reload(); }}
            style={{ background:"none", border:"none",
              color: C.muted, fontSize:9, cursor:"pointer",
              opacity:0.4, letterSpacing:"0.1em" }}>
            ↺ Onboarding'i Sıfırla
          </button>
        </div>

      </div>
    </motion.div>
  );
}

/* ─── AUTH MODAL PLACEHOLDER ────────────────────────────────────── */
function AuthPlaceholder({ onGeri }) {
  return (
    <motion.div key="auth"
      initial={{ opacity:0 }} animate={{ opacity:1 }}
      exit={{ opacity:0 }}
      style={{ display:"flex", flexDirection:"column",
        alignItems:"center", justifyContent:"center",
        minHeight:"100vh", gap:16 }}>
      <p style={{ fontSize:11, color: C.muted,
        letterSpacing:"0.2em" }}>
        AuthGateway.jsx burada render edilecek
      </p>
      <button onClick={onGeri}
        style={{ background:"none",
          border:`1px solid ${C.goldB}`,
          borderRadius:3, padding:"8px 18px",
          color: C.gold, cursor:"pointer", fontSize:11 }}>
        ← Geri
      </button>
    </motion.div>
  );
}

/* ─── ANA BİLEŞEN ───────────────────────────────────────────────── */
export default function App() {
  const [view,    setView]    = useState("BOOT");
  const [session, setSession] = useState(null);

  // İlk yükleme: localStorage kontrolü
  useEffect(() => {
    const saved = loadSession();
    if (saved) {
      setSession(saved);
      setView("VITRIN");
    } else {
      setView("ONBOARDING");
    }
  }, []);

  /* Onboarding tamamlandı */
  const handleOnboardingDone = (data) => {
    // data = { lang, coords }
    saveSession(data);
    setSession(data);
    setView("VITRIN");
  };

  /* Admin butonu */
  const handleAdmin = () => setView("AUTH");

  /* Çıkış */
  const handleCikis = () => setView("VITRIN");

  if (view === "BOOT") return null;  // localStorage okunana kadar boş

  return (
    <div style={{
      background: C.bg, minHeight:"100vh",
      color: C.text,
      fontFamily:"'Segoe UI',system-ui,sans-serif",
    }}>
      <AnimatePresence mode="wait">

        {view === "ONBOARDING" && (
          <OnboardingScreen key="ob" onDone={handleOnboardingDone}/>
        )}

        {view === "VITRIN" && (
          <VitrinPage key="vt"
            session={session}
            onAdmin={handleAdmin}
            onCikis={handleCikis}/>
        )}

        {view === "AUTH" && (
          /* AuthGateway hazır olunca:
             <AuthGateway key="auth"
               onClose={() => setView("VITRIN")}
               onAuth={(s) => {
                 if (s.rol === "MASTER")   setView("MASTER_PANEL");
                 if (s.rol === "DT_ADMIN") setView("DT_PANEL");
               }}
             />
          */
          <AuthPlaceholder key="auth" onGeri={() => setView("VITRIN")}/>
        )}

        {view === "DT_PANEL" && (
          /* <TheaterAdminPanel key="dt" onCikis={handleCikis}/> */
          <motion.div key="dt"
            initial={{ opacity:0 }} animate={{ opacity:1 }}
            style={{ display:"flex", alignItems:"center",
              justifyContent:"center", minHeight:"100vh" }}>
            <p style={{ color: C.muted, fontSize:11,
              letterSpacing:"0.15em" }}>
              TheaterAdminPanel_v8.jsx bağlanacak
            </p>
          </motion.div>
        )}

        {view === "MASTER_PANEL" && (
          /* <MasterPanel key="mp" onCikis={handleCikis}/> */
          <motion.div key="mp"
            initial={{ opacity:0 }} animate={{ opacity:1 }}
            style={{ display:"flex", alignItems:"center",
              justifyContent:"center", minHeight:"100vh" }}>
            <p style={{ color: C.muted, fontSize:11,
              letterSpacing:"0.15em" }}>
              MasterPanel_final.jsx bağlanacak
            </p>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
