/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║     NAR REHBERİ — App.jsx (State Routing Örneği)               ║
 * ║                                                                  ║
 * ║     View Hiyerarşisi:                                            ║
 * ║       MAIN   → Ana arama ekranı (IDLE/ANALYZING/RESULT)         ║
 * ║       AUTH   → Giriş Kapısı modal açık                          ║
 * ║       DT_ADMIN_PANEL  → TheaterAdminPanel                       ║
 * ║       MASTER_PANEL    → Master Admin (ileride)                   ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

import AuthGateway         from "./components/AuthGateway";
import TheaterAdminPanel   from "./components/TheaterAdminPanel";
// import MasterPanel      from "./components/MasterPanel"; // ileride

// ── Ana uygulama içeriğiniz (mevcut IDLE/ANALYZING/RESULT FSM'niz)
// import MainApp from "./components/MainApp";

export default function App() {
  // ─── Oturum state'i ────────────────────────────────────────────────────────
  // session: null | { rol: "USER" | "DT_ADMIN" | "MASTER", ad: string }
  const [session, setSession] = useState(null);

  // ─── Hangi ekran gösterilecek ───────────────────────────────────────────────
  // "MAIN" | "AUTH_MODAL" | "DT_PANEL" | "MASTER_PANEL"
  const [view, setView]       = useState("MAIN");

  // ─── Auth sonucu → view routing ───────────────────────────────────────────
  const handleAuth = (ses) => {
    setSession(ses);
    switch (ses.rol) {
      case "DT_ADMIN": setView("DT_PANEL");     break;
      case "MASTER":   setView("MASTER_PANEL"); break;
      case "USER":     setView("MAIN");         break; // modal kapanır, ana ekrana döner
      default:         setView("MAIN");
    }
  };

  const handleCikis = () => {
    setSession(null);
    setView("MAIN");
  };

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div style={{ background: "#0d0d12", minHeight: "100vh" }}>

      {/* ── Yönetim Butonu (sağ üst) ───────────────────────────────────── */}
      {view === "MAIN" && (
        <div style={{ position: "fixed", top: 16, right: 16, zIndex: 40 }}>
          {session ? (
            // Giriş yapılmışsa: rol rozetini göster + çıkış
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span style={{ fontSize: 10, color: "#D4AF37",
                letterSpacing: "0.12em", opacity: 0.7 }}>
                {session.ad}
              </span>
              <button onClick={handleCikis} style={navBtn}>Çıkış</button>
            </div>
          ) : (
            <button onClick={() => setView("AUTH_MODAL")} style={navBtn}>
              Yönetim
            </button>
          )}
        </div>
      )}

      {/* ── Ana Ekran ──────────────────────────────────────────────────── */}
      <AnimatePresence mode="wait">
        {view === "MAIN" && (
          <motion.div key="main"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            {/*
              Mevcut FSM arayüzünüz burada:
              <MainApp session={session} />

              Şimdilik placeholder:
            */}
            <div style={{ display: "flex", alignItems: "center",
              justifyContent: "center", minHeight: "100vh",
              color: "rgba(240,234,218,0.4)", fontFamily: "serif",
              fontSize: 14, letterSpacing: "0.15em" }}>
              NAR REHBERİ — ANA EKRAN
            </div>
          </motion.div>
        )}

        {/* ── Auth Modal ─────────────────────────────────────────────── */}
        {view === "AUTH_MODAL" && (
          <AuthGateway
            onClose={() => setView("MAIN")}
            onAuth={handleAuth}
          />
        )}

        {/* ── Tiyatro Admin Paneli ────────────────────────────────────── */}
        {view === "DT_PANEL" && (
          <motion.div key="dt-panel"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}>
            <TheaterAdminPanel onCikis={handleCikis} />
          </motion.div>
        )}

        {/* ── Master Panel (İleride) ─────────────────────────────────── */}
        {view === "MASTER_PANEL" && (
          <motion.div key="master-panel"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}>
            {/* <MasterPanel onCikis={handleCikis} /> */}
            <div style={{ display: "flex", flexDirection: "column",
              alignItems: "center", justifyContent: "center",
              minHeight: "100vh", gap: 16,
              color: "#a070d0", fontFamily: "serif" }}>
              <div style={{ fontSize: 32 }}>⬡</div>
              <div style={{ fontSize: 14, letterSpacing: "0.2em" }}>
                MASTER PANELİ — YAPIM AŞAMASINDA
              </div>
              <button onClick={handleCikis} style={navBtn}>
                Ana Sayfaya Dön
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Basit nav butonu stili
const navBtn = {
  background: "none",
  border: "1px solid rgba(212,175,55,0.25)",
  borderRadius: 3,
  padding: "8px 16px",
  color: "rgba(212,175,55,0.7)",
  cursor: "pointer",
  fontSize: 11,
  letterSpacing: "0.12em",
  fontFamily: "inherit",
};
